#!/usr/bin/env bash
# Place in .platform/hooks/postdeploy directory
sudo certbot -n -d ellarising4-4.is404.net --nginx --agree-tos --email santillb@byu.edu
#!/bin/bash
npm install --production






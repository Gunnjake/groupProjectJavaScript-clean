#!/bin/bash
# Ensure Elastic Beanstalk uses Node 20 for this environment.
. /opt/elasticbeanstalk/envvars
export PATH="/opt/elasticbeanstalk/node-install/node-v20.10.0-linux-x64/bin:$PATH"






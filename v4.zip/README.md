don't forget to make your own .env as well as install all the npm packages. 
please work
please work
please work
please work
last chance
